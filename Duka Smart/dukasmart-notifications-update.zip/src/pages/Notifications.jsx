import { useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../context/AppContext.jsx";

const TABS = ["All", "Out of stock", "Low stock"];

export default function Notifications() {
  const { alerts, readIds, unread, markRead, markAllRead } = useApp();
  const [tab, setTab] = useState("All");

  const shown = alerts.filter((a) => tab === "All" || (tab === "Out of stock" ? a.kind === "out" : a.kind === "low"));

  return (
    <>
      <div className="top">
        <div>
          <h1>Notifications</h1>
          <p className="muted">{unread > 0 ? `${unread} new alert${unread === 1 ? "" : "s"} about your stock.` : "You are all caught up."}</p>
        </div>
        <button className="btn out" onClick={markAllRead} disabled={unread === 0}>Mark all as read</button>
      </div>

      <div className="tabs">
        {TABS.map((t) => (
          <button key={t} className={t === tab ? "on" : ""} onClick={() => setTab(t)}>{t}</button>
        ))}
      </div>

      <div className="card" style={{ padding: 0 }}>
        {shown.length === 0 && (
          <p className="muted" style={{ padding: 18 }}>
            {alerts.length === 0 ? "No alerts. Everything is well stocked." : "No alerts in this group."}
          </p>
        )}
        {shown.map((a) => {
          const p = a.product;
          const isNew = !readIds.includes(a.id);
          return (
            <div className={"notif" + (isNew ? " unread" : "")} key={a.id}>
              <span className="ico">{a.kind === "out" ? "🚫" : "⚠️"}</span>
              <div className="grow">
                <b>{p.emoji} {p.name} {a.kind === "out" ? "is out of stock" : "is running low"}</b><br />
                <small className="muted">{p.qty === 0 ? "None left" : `${p.qty} left`} · reorder at {p.minStock}</small>
              </div>
              <span className={"chip " + a.kind}>{a.kind === "out" ? "Out" : "Low"}</span>
              <div className="actions">
                <Link className="btn out" to="/suppliers">Reorder</Link>
                {isNew && <button className="link" onClick={() => markRead(a.id)}>Mark as read</button>}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
